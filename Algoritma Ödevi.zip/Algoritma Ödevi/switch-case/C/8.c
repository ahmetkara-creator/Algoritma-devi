#include <stdio.h>

int main() {
    int secim;
    double a, b;

    printf("Birinci sayi: "); scanf("%lf", &a);
    printf("Ikinci sayi: "); scanf("%lf", &b);
    printf("1-Toplama 2-Cikarma 3-Carpma 4-Bolme: "); scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Toplam = %.2lf\n", a+b); break;
        case 2: printf("Fark = %.2lf\n", a-b); break;
        case 3: printf("Carpim = %.2lf\n", a*b); break;
        case 4: 
            if(b != 0) printf("Bolum = %.2lf\n", a/b);
            else printf("Sifira bolme hatasi!\n");
            break;
        default: printf("Gecersiz secim!\n"); break;
    }

    return 0;
}
