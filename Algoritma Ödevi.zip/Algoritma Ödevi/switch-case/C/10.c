#include <stdio.h>

int main() {
    int secim;

    printf("Menu secimi yapin (1-Ekle, 2-Sil, 3-Guncelle, 4-Listele): ");
    scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Ekleme islemi secildi\n"); break;
        case 2: printf("Silme islemi secildi\n"); break;
        case 3: printf("Guncelleme islemi secildi\n"); break;
        case 4: printf("Listeleme islemi secildi\n"); break;
        default: printf("Gecersiz secim\n"); break;
    }

    return 0;
}
