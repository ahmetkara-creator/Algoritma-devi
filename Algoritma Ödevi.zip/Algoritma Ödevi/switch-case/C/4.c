#include <stdio.h>

int main() {
    int rakam;

    printf("0-9 arasi rakam girin: ");
    scanf("%d", &rakam);

    switch(rakam) {
        case 0: printf("Sifir\n"); break;
        case 1: printf("Bir\n"); break;
        case 2: printf("Iki\n"); break;
        case 3: printf("Uc\n"); break;
        case 4: printf("Dort\n"); break;
        case 5: printf("Bes\n"); break;
        case 6: printf("Alti\n"); break;
        case 7: printf("Yedi\n"); break;
        case 8: printf("Sekiz\n"); break;
        case 9: printf("Dokuz\n"); break;
        default: printf("Gecersiz rakam!\n"); break;
    }

    return 0;
}
