#include <stdio.h>

int main() {
    char harf;

    printf("Bir harf girin: ");
    scanf(" %c", &harf);

    switch(harf) {
        case 'a': case 'e': case 'i': case 'o': case 'u':
        case 'A': case 'E': case 'I': case 'O': case 'U':
            printf("Sesli harf\n"); break;
        default: printf("Sessiz harf\n"); break;
    }
