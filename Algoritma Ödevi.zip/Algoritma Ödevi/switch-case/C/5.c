#include <stdio.h>

int main() {
    int gun;

    printf("1-7 arasi gun numarasini girin: ");
    scanf("%d", &gun);

    switch(gun) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5: printf("Hafta ici\n"); break;
        case 6:
        case 7: printf("Hafta sonu\n"); break;
        default: printf("Gecersiz gun numarasi!\n"); break;
    }

    return 0;
}
