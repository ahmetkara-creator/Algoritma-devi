#include <stdio.h>

int main() {
    int ay;

    printf("1-12 arasi ay numarasini girin: ");
    if(scanf("%d", &ay) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    switch(ay) {
        case 1: printf("Ocak\n"); break;
        case 2: printf("Subat\n"); break;
        case 3: printf("Mart\n"); break;
        case 4: printf("Nisan\n"); break;
        case 5: printf("Mayis\n"); break;
        case 6: printf("Haziran\n"); break;
        case 7: printf("Temmuz\n"); break;
        case 8: printf("Agustos\n"); break;
        case 9: printf("Eylul\n"); break;
        case 10: printf("Ekim\n"); break;
        case 11: printf("Kasim\n"); break;
        case 12: printf("Aralik\n"); break;
        default: printf("Gecersiz ay numarasi!\n"); break;
    }

    return 0;
}
