#include <stdio.h>

int main() {
    int ay;

    printf("Ay numarasini girin (1-12): ");
    scanf("%d", &ay);

    switch(ay) {
        case 12: case 1: case 2: printf("Kis\n"); break;
        case 3: case 4: case 5: printf("Ilkbahar\n"); break;
        case 6: case 7: case 8: printf("Yaz\n"); break;
        case 9: case 10: case 11: printf("Sonbahar\n"); break;
        default: printf("Gecersiz ay numarasi!\n"); break;
    }

    return 0;
}
