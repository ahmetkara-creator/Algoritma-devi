#include <stdio.h>

int main() {
    double a, b;
    char islem;

    printf("Birinci sayiyi girin: ");
    scanf("%lf", &a);
    printf("Islemi girin (+, -, *, /): ");
    scanf(" %c", &islem);
    printf("Ikinci sayiyi girin: ");
    scanf("%lf", &b);

    switch(islem) {
        case '+': printf("Sonuc = %.2lf\n", a+b); break;
        case '-': printf("Sonuc = %.2lf\n", a-b); break;
        case '*': printf("Sonuc = %.2lf\n", a*b); break;
        case '/': 
            if(b != 0) printf("Sonuc = %.2lf\n", a/b);
            else printf("Sifira bolme hatasi!\n");
            break;
        default: printf("Gecersiz islem!\n"); break;
    }

    return 0;
}
