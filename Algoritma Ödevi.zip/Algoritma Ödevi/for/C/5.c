#include <stdio.h>

int main() {
    int n;
    long fakt = 1;

    printf("Bir sayi girin: ");
    if(scanf("%d", &n) != 1 || n < 0) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    for(int i = 1; i <= n; i++) {
        fakt *= i;
    }

    printf("%d! = %ld\n", n, fakt);
    return 0;
}
