#include <stdio.h>

int main() {
    int n;

    printf("Bir sayi girin: ");
    if(scanf("%d", &n) != 1 || n < 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    for(int i = 1; i <= n; i++) {
        printf("%d ", i);
    }

    printf("\n");
    return 0;
}
