#include <stdio.h>

int main() {
    int n, toplam = 0;

    printf("Bir sayi girin: ");
    if(scanf("%d", &n) != 1 || n < 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    for(int i = 1; i <= n; i++) {
        if(i % 3 == 0)
            toplam += i;
    }

    printf("3'e bolunen sayilarin toplami = %d\n", toplam);
    return 0;
}
