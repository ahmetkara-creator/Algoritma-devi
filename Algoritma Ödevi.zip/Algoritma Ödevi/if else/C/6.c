#include <stdio.h>

int main() {
    char harf;

    printf("Bir harf girin: ");
    if(scanf(" %c", &harf) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if(harf=='a'||harf=='e'||harf=='i'||harf=='o'||harf=='u'||
       harf=='A'||harf=='E'||harf=='I'||harf=='O'||harf=='U') {
        printf("Sesli harf\n");
    } else {
        printf("Sessiz harf\n");
    }

    return 0;
}
