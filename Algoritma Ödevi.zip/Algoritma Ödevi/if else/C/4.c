#include <stdio.h>

int main() {
    int notu;

    printf("Notunuzu girin: ");
    if(scanf("%d", &notu) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if(notu >= 50) {
        printf("Gectiniz\n");
    } else {
        printf("Kaldiniz\n");
    }

    return 0;
}
