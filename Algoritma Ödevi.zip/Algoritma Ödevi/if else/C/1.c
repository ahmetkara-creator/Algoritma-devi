#include <stdio.h>

int main() {
    int sayi;
    printf("Sayi girin: ");
    scanf("%d", &sayi);

    if(sayi > 0) {
        printf("Pozitif sayi\n");
    } else {
        printf("Pozitif degil\n");
    }

    return 0;
}