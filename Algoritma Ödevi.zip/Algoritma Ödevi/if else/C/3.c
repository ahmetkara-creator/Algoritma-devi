#include <stdio.h>

int main() {
    int yas;

    printf("Yasinizi girin: ");
    if(scanf("%d", &yas) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if(yas > 18) {
        printf("Resitsiniz\n");
    } else {
        printf("Resit degilsiniz\n");
    }

    return 0;
}
