#include <stdio.h>

int main() {
    int sayi;

    printf("Sayi girin: ");
    if(scanf("%d", &sayi) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if(sayi >= 0 && sayi < 10) {
        printf("Tek haneli\n");
    } else {
        printf("Cok haneli\n");
    }

    return 0;
}
