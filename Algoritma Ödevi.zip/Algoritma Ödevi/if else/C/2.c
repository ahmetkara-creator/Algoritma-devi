#include <stdio.h>

int main() {
    int sayi;
    printf("Sayi girin: ");
    scanf("%d", &sayi);

    if(sayi % 2 == 0) {
        printf("Cift sayi\n");
    } else {
        printf("Tek sayi\n");
    }

    return 0;
}