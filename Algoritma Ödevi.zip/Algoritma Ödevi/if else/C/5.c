#include <stdio.h>

int main() {
    int sicaklik;

    printf("Sicaklik degeri girin: ");
    if(scanf("%d", &sicaklik) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if(sicaklik > 30) {
        printf("Cok sicak\n");
    } else {
        printf("Sicaklik normal\n");
    }

    return 0;
}
