#include <stdio.h>

int main() {
    int kenar1, kenar2, kenar3;

    printf("Uc kenar girin: ");
    if(scanf("%d %d %d", &kenar1, &kenar2, &kenar3) != 3) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if((kenar1+kenar2>kenar3) && (kenar1+kenar3>kenar2) && (kenar2+kenar3>kenar1)) {
        printf("Ucgen cizilebilir\n");
    } else {
        printf("Ucgen cizilemez\n");
    }

    return 0;
}
