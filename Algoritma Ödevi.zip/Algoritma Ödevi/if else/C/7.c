#include <stdio.h>

int main() {
    int sayi;

    printf("Sayi girin: ");
    if(scanf("%d", &sayi) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    if(sayi < 0) {
        printf("Negatif sayi\n");
    } else {
        printf("Negatif degil\n");
    }

    return 0;
}
