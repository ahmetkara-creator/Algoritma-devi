#include <stdio.h>
#include <string.h>

int main() {
    char sifre[20];
    const char dogru[] = "12345";

    do {
        printf("Sifre girin: ");
        scanf("%s", sifre);

        if(strcmp(sifre, dogru) != 0)
            printf("Yanlis sifre, tekrar deneyin.\n");

    } while(strcmp(sifre, dogru) != 0);

    printf("Sifre dogru!\n");
    return 0;
}
