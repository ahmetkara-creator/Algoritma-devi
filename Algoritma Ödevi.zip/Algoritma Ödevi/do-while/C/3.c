#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    do {
        printf("Pozitif sayi girin (bitirmek icin 0): ");
        if(scanf("%d", &sayi) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

        if(sayi > 0)
            toplam += sayi;

    } while(sayi != 0);

    printf("Toplam = %d\n", toplam);
    return 0;
}
