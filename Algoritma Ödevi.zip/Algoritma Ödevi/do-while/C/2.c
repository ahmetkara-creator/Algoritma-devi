#include <stdio.h>

int main() {
    int n, i = 1;

    printf("Bir sayi girin: ");
    if(scanf("%d", &n) != 1 || n < 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    do {
        if(i % 2 == 0)
            printf("%d ", i);
        i++;
    } while(i <= n);

    printf("\n");
    return 0;
}
