#include <stdio.h>

int main() {
    int n, i = 1;

    printf("Bir sayi girin: ");
    if(scanf("%d", &n) != 1 || n < 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    do {
        printf("%d^2 = %d\n", i, i*i);
        i++;
    } while(i <= n);

    return 0;
}
