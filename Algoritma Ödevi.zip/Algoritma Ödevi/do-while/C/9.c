#include <stdio.h>

int main() {
    int sayi;

    do {
        printf("Bir sayi girin (bitirmek icin 5): ");
        if(scanf("%d", &sayi) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

    } while(sayi != 5);

    printf("5 sayisi girildi, program bitiyor.\n");
    return 0;
}
