#include <stdio.h>

int main() {
    int sayi;
    long carpim = 1;

    do {
        printf("Pozitif sayi girin (bitirmek icin 0): ");
        if(scanf("%d", &sayi) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

        if(sayi > 0)
            carpim *= sayi;

    } while(sayi != 0);

    printf("Pozitif sayilarin carpimi = %ld\n", carpim);
    return 0;
}
