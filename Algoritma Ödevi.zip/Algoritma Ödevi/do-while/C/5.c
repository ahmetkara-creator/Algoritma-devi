#include <stdio.h>

int main() {
    int sayi, toplam = 0, adet = 0;

    do {
        printf("Pozitif sayi girin (bitirmek icin negatif sayi): ");
        if(scanf("%d", &sayi) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

        if(sayi >= 0) {
            toplam += sayi;
            adet++;
        }

    } while(sayi >= 0);

    if(adet == 0)
        printf("Hiç sayi girilmedi.\n");
    else
        printf("Ortalama = %.2f\n", (float)toplam / adet);

    return 0;
}
