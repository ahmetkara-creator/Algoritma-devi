#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    printf("Pozitif sayilar girin (bitirmek icin 0): ");
    while(1) {
        if(scanf("%d", &sayi) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

        if(sayi == 0)
            break;

        if(sayi > 0)
            toplam += sayi;
    }

    printf("Toplam = %d\n", toplam);

    return 0;
}
