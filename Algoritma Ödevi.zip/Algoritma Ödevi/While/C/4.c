#include <stdio.h>

int main() {
    int tahmin;
    const int gizli = 7;

    printf("1-10 arasinda bir sayi tahmin edin: ");

    while(1) {
        if(scanf("%d", &tahmin) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

        if(tahmin == gizli) {
            printf("Tebrikler! Dogru tahmin.\n");
            break;
        } else {
            printf("Yanlis, tekrar deneyin: ");
        }
    }

    return 0;
}
