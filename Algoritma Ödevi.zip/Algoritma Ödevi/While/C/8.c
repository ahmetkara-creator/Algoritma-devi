#include <stdio.h>

int main() {
    int sayi, toplam = 0, adet = 0;

    printf("Pozitif sayilar girin (bitirmek icin negatif sayi): ");
    while(1) {
        if(scanf("%d", &sayi) != 1) {
            printf("Gecersiz giris!\n");
            return 1;
        }

        if(sayi < 0)
            break;

        toplam += sayi;
        adet++;
    }

    if(adet == 0)
        printf("Hiç sayı girilmedi.\n");
    else
        printf("Toplam = %d, Ortalama = %.2f\n", toplam, (float)toplam/adet);

    return 0;
}
