#include <stdio.h>

int main() {
    int n, i = 1;

    printf("Bir sayi girin: ");
    if(scanf("%d", &n) != 1) {
        printf("Gecersiz giris!\n");
        return 1;
    }

    while(i <= n) {
        if(i % 2 == 0)
            printf("%d ", i);
        i++;
    }
    printf("\n");

    return 0;
}
