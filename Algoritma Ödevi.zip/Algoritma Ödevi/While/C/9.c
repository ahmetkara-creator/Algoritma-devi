#include <stdio.h>
#include <string.h>

int main() {
    char sifre[20];
    const char dogru[] = "12345";

    printf("Sifreyi girin: ");
    while(1) {
        scanf("%s", sifre);
        if(strcmp(sifre, dogru) == 0) {
            printf("Sifre dogru!\n");
            break;
        } else {
            printf("Yanlis sifre, tekrar deneyin: ");
        }
    }

    return 0;
}
